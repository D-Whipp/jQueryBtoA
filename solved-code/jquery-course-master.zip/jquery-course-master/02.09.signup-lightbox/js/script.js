$(function () {

  // Fade in lightbox after half a second
  $(".lightbox").delay(500).fadeIn(1000);

});
